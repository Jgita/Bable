import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-unauthorized-attempts',
  templateUrl: './unauthorized-attempts.component.html',
  styleUrls: ['./unauthorized-attempts.component.scss']
})
export class UnauthorizedAttemptsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
