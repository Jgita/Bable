import {Component, OnInit} from '@angular/core';

@Component({
    selector: 'app-risk-adjustment',
    templateUrl: './risk-adjustment.component.html',
    styleUrls: ['./risk-adjustment.component.scss']
})
export class RiskAdjustmentComponent implements OnInit {

    constructor() {
    }

    ngOnInit() {
    }

}
