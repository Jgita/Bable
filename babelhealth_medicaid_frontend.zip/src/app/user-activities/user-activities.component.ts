import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-activities',
  templateUrl: './user-activities.component.html',
  styleUrls: ['./user-activities.component.scss']
})
export class UserActivitiesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
